const mongoose = require('mongoose');

const friendsSchema = new mongoose.Schema({
    classcode: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    }

});

const friends = mongoose.model('friends', friendsSchema);
module.exports = friends;