const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
    organization: {
        type: String,
        required: true
    },
    jobrole: {
        type: String,
        required: true
    },
    jobdescription: {
        type: String,
        required: true
    },
    joblink: {
        type: String,
        required: true
    },
    mail: {
        type: String,
        required: true
    }
});

const job = mongoose.model('JOBS', jobSchema);
module.exports = job;