const mongoose = require('mongoose');

const classAnnounceSchema = new mongoose.Schema({
    classcode: {
        type: String,
        required: true
    },
    subject: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    }

});

const announce = mongoose.model('announce', classAnnounceSchema);
module.exports = announce;