const mongoose = require('mongoose');

const createSchema = new mongoose.Schema({
    userid: {
        type: String,
        required: true
    },
    classcode: {
        type: String,
        required: true
    },
    classname: {
        type: String,
        required: true
    },
    classdescription: {
        type: String,
        required: true
    },
});

const create = mongoose.model('CREATES', createSchema);
module.exports = create;